from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

# Lista inicial de músicas
musicas = [
    {"nome": "Naquela mesa", "genero": "MPB", "artista": "Nelson Gonçalves"},
    {"nome": "Garota de Ipanema", "genero": "Bossa Nova, MPB", "artista": "Tom Jobim"},
    {"nome": "Telefone Mudo", "genero": "Sertanejo Raiz", "artista": "Chitãozinho e Chororó"},
    {"nome": "Wave", "genero": "Bossa Nova, MPB", "artista": "Tom Jobim"},
    {"nome": "João e Maria", "genero": "MPB", "artista": "Chico Buarque"}
]


@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        nome = request.form['nome']
        genero = request.form['genero']
        artista = request.form['artista']
        musicas.append({"nome": nome, "genero": genero, "artista": artista})
        return redirect("/")

    return render_template("index.html", musicas=musicas)


@app.route('/editar/<int:index>', methods=['GET', 'POST'])
def editar(index):
    if request.method == 'POST':
        nome = request.form['nome']
        genero = request.form['genero']
        artista = request.form['artista']
        musicas[index] = {"nome": nome, "genero": genero, "artista":artista}
        return redirect("/")

    return render_template('editar.html', musica=musicas[index], index=index)


@app.route('/delete/<int:index>', methods=['POST'])
def delete(index):
    if 0 <= index < len(musicas):
        musicas.pop(index)
    return redirect("/")


if __name__ == "__main__":
    app.run(debug=True)
